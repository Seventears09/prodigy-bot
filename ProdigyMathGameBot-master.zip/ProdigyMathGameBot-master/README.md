﻿# ProdigyMathGameBot
## This bot allows you to access Prodigy items, pets, statistics, and more! Additionally, it syncs with the Prodigy API, so it automatically updates!
Prefix - `p!`
---------
## Invite it [here!](https://discord.com/oauth2/authorize?client_id=746458284059394050&scope=bot&permissions=314432)
---------
#### Current commands:
### p!backpack
#### Gives you a list of categories and items. After answering which you want, you can get more detailed info on a single item. | Special items have special data, like potions.
### p!petlist
#### Gives you a list of elements and then pets to choose from. After answering which you want, you can get more detailed info on a single item.
### p!spellbook
#### Gives you a list of elements and then spells to choose from. After answering which you want, you can get more detailed info on a single spell. | Some spells are outdated and have less data.
### p!info
#### Gives info on the bot.

----

***Licensed under the GNU General Public License V3***

